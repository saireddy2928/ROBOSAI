import Link from "next/link"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface TopRankedListProps {
  category?: string
}

export function TopRankedList({ category }: TopRankedListProps) {
  // This would come from an API in a real application
  const figures = [
    {
      id: 1,
      name: "Elon Musk",
      image: "/placeholder.svg?height=80&width=80",
      category: "entrepreneurs",
      score: 94,
      credibility: 92,
      relevance: 98,
      impact: 96,
      change: "up",
    },
    {
      id: 2,
      name: "Oprah Winfrey",
      image: "/placeholder.svg?height=80&width=80",
      category: "entrepreneurs",
      score: 92,
      credibility: 95,
      relevance: 90,
      impact: 94,
      change: "stable",
    },
    {
      id: 3,
      name: "MrBeast",
      image: "/placeholder.svg?height=80&width=80",
      category: "creators",
      score: 89,
      credibility: 86,
      relevance: 95,
      impact: 90,
      change: "up",
    },
    {
      id: 4,
      name: "Serena Williams",
      image: "/placeholder.svg?height=80&width=80",
      category: "athletes",
      score: 88,
      credibility: 92,
      relevance: 85,
      impact: 90,
      change: "down",
    },
    {
      id: 5,
      name: "Marques Brownlee",
      image: "/placeholder.svg?height=80&width=80",
      category: "creators",
      score: 87,
      credibility: 94,
      relevance: 88,
      impact: 82,
      change: "up",
    },
  ]

  const filteredFigures = category ? figures.filter((figure) => figure.category === category) : figures

  return (
    <div className="space-y-4">
      {filteredFigures.map((figure, index) => (
        <Link href={`/profile/${figure.id}`} key={figure.id}>
          <Card className="hover:bg-muted/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="font-bold text-xl text-muted-foreground w-6">{index + 1}</div>
                <div className="relative h-12 w-12 overflow-hidden rounded-full">
                  <Image src={figure.image || "/placeholder.svg"} alt={figure.name} fill className="object-cover" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{figure.name}</h3>
                    <Badge variant="outline" className="capitalize">
                      {figure.category}
                    </Badge>
                    {figure.change === "up" && (
                      <Badge variant="success" className="text-xs">
                        ↑
                      </Badge>
                    )}
                    {figure.change === "down" && (
                      <Badge variant="destructive" className="text-xs">
                        ↓
                      </Badge>
                    )}
                  </div>
                  <div className="mt-2 flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Influence Score</span>
                        <span className="font-medium">{figure.score}</span>
                      </div>
                      <Progress value={figure.score} className="h-1.5" />
                    </div>
                    <div className="flex gap-2 text-xs text-muted-foreground">
                      <div className="flex flex-col items-center">
                        <span>Cred</span>
                        <span className="font-medium">{figure.credibility}</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span>Rel</span>
                        <span className="font-medium">{figure.relevance}</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span>Imp</span>
                        <span className="font-medium">{figure.impact}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

