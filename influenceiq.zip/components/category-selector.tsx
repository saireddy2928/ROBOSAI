import { Button } from "@/components/ui/button"
import { Briefcase, Video, Trophy, Mic, Stethoscope, GraduationCap, Gavel, Palette } from "lucide-react"

export function CategorySelector() {
  const categories = [
    { name: "Entrepreneurs", icon: <Briefcase className="h-4 w-4" /> },
    { name: "Creators", icon: <Video className="h-4 w-4" /> },
    { name: "Athletes", icon: <Trophy className="h-4 w-4" /> },
    { name: "Entertainers", icon: <Mic className="h-4 w-4" /> },
    { name: "Healthcare", icon: <Stethoscope className="h-4 w-4" /> },
    { name: "Academics", icon: <GraduationCap className="h-4 w-4" /> },
    { name: "Politicians", icon: <Gavel className="h-4 w-4" /> },
    { name: "Artists", icon: <Palette className="h-4 w-4" /> },
  ]

  return (
    <div className="mt-8">
      <h2 className="text-xl font-bold mb-4">Browse by Category</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {categories.map((category) => (
          <Button key={category.name} variant="outline" className="h-auto py-3 justify-start gap-2">
            {category.icon}
            <span>{category.name}</span>
          </Button>
        ))}
      </div>
    </div>
  )
}

