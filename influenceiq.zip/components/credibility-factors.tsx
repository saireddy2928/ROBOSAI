"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Card, CardContent } from "@/components/ui/card"

export function CredibilityFactors() {
  // This would come from an API in a real application
  const data = [
    { name: "Expertise", score: 95 },
    { name: "Consistency", score: 88 },
    { name: "Transparency", score: 82 },
    { name: "Accuracy", score: 90 },
    { name: "Accountability", score: 85 },
    { name: "Third-party Validation", score: 94 },
  ]

  return (
    <div className="space-y-6">
      <div className="h-[250px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Bar dataKey="score" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-2">Strengths</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Strong track record of technical expertise</li>
              <li>Consistent delivery on major promises</li>
              <li>High third-party validation from industry experts</li>
              <li>Transparent communication about challenges</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-2">Areas for Improvement</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Occasional inconsistency in public statements</li>
              <li>Some transparency issues regarding business decisions</li>
              <li>Accountability could be improved for missed deadlines</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="rounded-lg bg-muted p-4">
        <h3 className="font-medium mb-2">Credibility Analysis</h3>
        <p className="text-sm">
          Our AI analyzes thousands of data points including public statements, business outcomes, expert opinions, and
          consistency over time to determine credibility scores. The subject's high expertise and third-party validation
          scores significantly boost their overall credibility, while there are opportunities to improve in transparency
          and accountability metrics.
        </p>
      </div>
    </div>
  )
}

