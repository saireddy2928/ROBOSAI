import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface TrendingFiguresProps {
  category?: string
}

export function TrendingFigures({ category }: TrendingFiguresProps) {
  // This would come from an API in a real application
  const figures = [
    {
      id: 101,
      name: "Mark Cuban",
      image: "/placeholder.svg?height=80&width=80",
      category: "entrepreneurs",
      changePercent: 12,
    },
    {
      id: 102,
      name: "Emma Chamberlain",
      image: "/placeholder.svg?height=80&width=80",
      category: "creators",
      changePercent: 24,
    },
    {
      id: 103,
      name: "LeBron James",
      image: "/placeholder.svg?height=80&width=80",
      category: "athletes",
      changePercent: 8,
    },
    {
      id: 104,
      name: "Sara Dietschy",
      image: "/placeholder.svg?height=80&width=80",
      category: "creators",
      changePercent: 32,
    },
    {
      id: 105,
      name: "Whitney Wolfe Herd",
      image: "/placeholder.svg?height=80&width=80",
      category: "entrepreneurs",
      changePercent: 18,
    },
  ]

  const filteredFigures = category ? figures.filter((figure) => figure.category === category) : figures

  return (
    <div className="grid grid-cols-1 gap-4">
      {filteredFigures.map((figure) => (
        <Link href={`/profile/${figure.id}`} key={figure.id}>
          <Card className="hover:bg-muted/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="relative h-12 w-12 overflow-hidden rounded-full">
                  <Image src={figure.image || "/placeholder.svg"} alt={figure.name} fill className="object-cover" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{figure.name}</h3>
                      <Badge variant="outline" className="capitalize">
                        {figure.category}
                      </Badge>
                    </div>
                    <Badge variant="success" className="ml-auto">
                      +{figure.changePercent}%
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">Gaining significant influence this week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

