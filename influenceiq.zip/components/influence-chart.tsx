"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export function InfluenceChart() {
  // This would come from an API in a real application
  const data = [
    { month: "Jan", score: 82, credibility: 80, relevance: 85, impact: 81 },
    { month: "Feb", score: 85, credibility: 83, relevance: 87, impact: 84 },
    { month: "Mar", score: 83, credibility: 85, relevance: 84, impact: 82 },
    { month: "Apr", score: 87, credibility: 86, relevance: 88, impact: 86 },
    { month: "May", score: 89, credibility: 87, relevance: 90, impact: 88 },
    { month: "Jun", score: 86, credibility: 85, relevance: 89, impact: 85 },
    { month: "Jul", score: 88, credibility: 88, relevance: 91, impact: 87 },
    { month: "Aug", score: 90, credibility: 89, relevance: 92, impact: 89 },
    { month: "Sep", score: 92, credibility: 90, relevance: 94, impact: 91 },
    { month: "Oct", score: 91, credibility: 91, relevance: 93, impact: 90 },
    { month: "Nov", score: 93, credibility: 92, relevance: 95, impact: 93 },
    { month: "Dec", score: 94, credibility: 92, relevance: 98, impact: 96 },
  ]

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis domain={[60, 100]} />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="score" stroke="#8884d8" strokeWidth={2} />
          <Line type="monotone" dataKey="credibility" stroke="#82ca9d" strokeWidth={1} />
          <Line type="monotone" dataKey="relevance" stroke="#ffc658" strokeWidth={1} />
          <Line type="monotone" dataKey="impact" stroke="#ff8042" strokeWidth={1} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

