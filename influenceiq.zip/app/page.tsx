import Link from "next/link"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingFigures } from "@/components/trending-figures"
import { TopRankedList } from "@/components/top-ranked-list"
import { CategorySelector } from "@/components/category-selector"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <span className="inline-block font-bold text-xl">InfluenceIQ</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="#"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Rankings
              </Link>
              <Link
                href="#"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Categories
              </Link>
              <Link
                href="#"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Methodology
              </Link>
              <Link
                href="#"
                className="flex items-center text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                About
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center space-x-4 sm:justify-end">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search public figures..." className="w-full rounded-md pl-8" />
            </div>
            <Button>Sign In</Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-muted/50 to-background">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Discover Who Really Matters
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  InfluenceIQ measures true impact beyond fleeting fame, ranking public figures by credibility,
                  sustained relevance, and genuine influence.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="container px-4 py-12 md:px-6">
          <CategorySelector />

          <Tabs defaultValue="all" className="mt-8">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="entrepreneurs">Entrepreneurs</TabsTrigger>
              <TabsTrigger value="creators">Creators</TabsTrigger>
              <TabsTrigger value="athletes">Athletes</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Top Ranked</h2>
                  <TopRankedList />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-4">Trending This Week</h2>
                  <TrendingFigures />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="entrepreneurs" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Top Entrepreneurs</h2>
                  <TopRankedList category="entrepreneurs" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-4">Trending Entrepreneurs</h2>
                  <TrendingFigures category="entrepreneurs" />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="creators" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Top Creators</h2>
                  <TopRankedList category="creators" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-4">Trending Creators</h2>
                  <TrendingFigures category="creators" />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="athletes" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Top Athletes</h2>
                  <TopRankedList category="athletes" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-4">Trending Athletes</h2>
                  <TrendingFigures category="athletes" />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <footer className="w-full border-t bg-background py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} InfluenceIQ. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Terms
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Privacy
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

