import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Twitter, Instagram, Globe, TrendingUp, Award, Clock, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { InfluenceChart } from "@/components/influence-chart"
import { CredibilityFactors } from "@/components/credibility-factors"

export default function ProfilePage({ params }: { params: { id: string } }) {
  // In a real app, this would fetch data based on the ID
  const profile = {
    id: params.id,
    name: "Elon Musk",
    image: "/placeholder.svg?height=200&width=200",
    category: "entrepreneurs",
    title: "CEO of SpaceX, Tesla, X, and Neuralink",
    bio: "Entrepreneur and business magnate focused on space exploration, electric vehicles, and sustainable energy.",
    score: 94,
    credibility: 92,
    relevance: 98,
    impact: 96,
    socialMedia: {
      twitter: "elonmusk",
      instagram: "elonmusk",
      website: "tesla.com",
    },
    stats: {
      rank: 1,
      trending: "+3",
      timeInTop10: "156 weeks",
      followers: "128.5M",
    },
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 py-8 md:px-6">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-6">
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Rankings</span>
        </Link>

        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="relative h-32 w-32 overflow-hidden rounded-full mb-4">
                    <Image src={profile.image || "/placeholder.svg"} alt={profile.name} fill className="object-cover" />
                  </div>
                  <h1 className="text-2xl font-bold">{profile.name}</h1>
                  <Badge variant="outline" className="mt-2 capitalize">
                    {profile.category}
                  </Badge>
                  <p className="text-sm text-muted-foreground mt-2">{profile.title}</p>

                  <div className="flex gap-4 mt-4">
                    <Button variant="outline" size="icon" asChild>
                      <Link href={`https://twitter.com/${profile.socialMedia.twitter}`} target="_blank">
                        <Twitter className="h-4 w-4" />
                        <span className="sr-only">Twitter</span>
                      </Link>
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <Link href={`https://instagram.com/${profile.socialMedia.instagram}`} target="_blank">
                        <Instagram className="h-4 w-4" />
                        <span className="sr-only">Instagram</span>
                      </Link>
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <Link href={`https://${profile.socialMedia.website}`} target="_blank">
                        <Globe className="h-4 w-4" />
                        <span className="sr-only">Website</span>
                      </Link>
                    </Button>
                  </div>

                  <div className="w-full mt-6 space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Influence Score</span>
                        <span className="font-medium">{profile.score}</span>
                      </div>
                      <Progress value={profile.score} className="h-2" />
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-lg bg-muted p-2">
                        <div className="text-xs text-muted-foreground">Credibility</div>
                        <div className="font-medium">{profile.credibility}</div>
                      </div>
                      <div className="rounded-lg bg-muted p-2">
                        <div className="text-xs text-muted-foreground">Relevance</div>
                        <div className="font-medium">{profile.relevance}</div>
                      </div>
                      <div className="rounded-lg bg-muted p-2">
                        <div className="text-xs text-muted-foreground">Impact</div>
                        <div className="font-medium">{profile.impact}</div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 w-full mt-6">
                    <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                      <TrendingUp className="h-4 w-4 text-muted-foreground mb-1" />
                      <div className="text-xs text-muted-foreground">Rank</div>
                      <div className="font-medium">
                        {profile.stats.rank} <span className="text-green-500 text-xs">{profile.stats.trending}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                      <Award className="h-4 w-4 text-muted-foreground mb-1" />
                      <div className="text-xs text-muted-foreground">Top 10</div>
                      <div className="font-medium">{profile.stats.timeInTop10}</div>
                    </div>
                    <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                      <Clock className="h-4 w-4 text-muted-foreground mb-1" />
                      <div className="text-xs text-muted-foreground">Consistency</div>
                      <div className="font-medium">High</div>
                    </div>
                    <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                      <Users className="h-4 w-4 text-muted-foreground mb-1" />
                      <div className="text-xs text-muted-foreground">Followers</div>
                      <div className="font-medium">{profile.stats.followers}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{profile.bio}</p>
              </CardContent>
            </Card>

            <Tabs defaultValue="influence" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="influence">Influence Trend</TabsTrigger>
                <TabsTrigger value="credibility">Credibility Factors</TabsTrigger>
                <TabsTrigger value="impact">Impact Analysis</TabsTrigger>
              </TabsList>
              <TabsContent value="influence" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Influence Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <InfluenceChart />
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="credibility" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Credibility Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CredibilityFactors />
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="impact" className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Impact Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        Impact is measured through a combination of direct influence (business outcomes, policy
                        changes), social influence (cultural shifts, behavioral changes), and long-term relevance.
                      </p>

                      <div className="space-y-2">
                        <h3 className="font-medium">Key Impact Metrics:</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Business value creation: 95/100</li>
                          <li>Industry transformation: 98/100</li>
                          <li>Public discourse influence: 94/100</li>
                          <li>Innovation catalyst: 97/100</li>
                          <li>Global reach: 96/100</li>
                        </ul>
                      </div>

                      <div className="rounded-lg bg-muted p-4 mt-4">
                        <h3 className="font-medium mb-2">AI Analysis Summary</h3>
                        <p className="text-sm">
                          Elon Musk's impact extends beyond traditional business metrics. His ventures have catalyzed
                          entire industries (electric vehicles, commercial space travel), while his public statements
                          frequently drive market movements and policy discussions. His consistent ability to remain
                          relevant across multiple domains contributes to his exceptionally high impact score.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}

