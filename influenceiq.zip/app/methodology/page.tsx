import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MethodologyPage() {
  return (
    <div className="container px-4 py-8 md:px-6">
      <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-6">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Rankings</span>
      </Link>

      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Our Methodology</h1>
        <p className="text-muted-foreground mb-8">How InfluenceIQ measures true influence beyond fleeting fame</p>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="credibility">Credibility</TabsTrigger>
            <TabsTrigger value="relevance">Relevance</TabsTrigger>
            <TabsTrigger value="impact">Impact</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>The InfluenceIQ Methodology</CardTitle>
                <CardDescription>A comprehensive approach to measuring true influence</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  Unlike traditional popularity metrics that focus on follower counts or viral moments, InfluenceIQ uses
                  a sophisticated AI-powered system to measure lasting influence across three key dimensions:
                </p>

                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Credibility</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">
                        Measures expertise, consistency, transparency, accuracy, and third-party validation.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Relevance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">
                        Evaluates sustained attention, cultural significance, and adaptability over time.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Impact</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">
                        Assesses tangible outcomes, behavioral changes, and lasting contributions.
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <h3 className="text-lg font-medium mt-6">Data Sources</h3>
                <p>Our AI system analyzes millions of data points from diverse sources:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Social media engagement and sentiment analysis</li>
                  <li>News and media coverage (quantity and quality)</li>
                  <li>Industry reports and expert opinions</li>
                  <li>Academic citations and research impact</li>
                  <li>Business metrics and market influence</li>
                  <li>Cultural and societal impact indicators</li>
                  <li>Historical trend analysis</li>
                </ul>

                <h3 className="text-lg font-medium mt-6">Scoring System</h3>
                <p>
                  Each public figure receives scores on a 0-100 scale for Credibility, Relevance, and Impact. These are
                  weighted according to their field and combined into an overall Influence Score. Rankings are updated
                  weekly, with trending indicators showing movement.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="credibility" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Credibility Methodology</CardTitle>
                <CardDescription>How we measure trustworthiness and authority</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>Credibility is a foundational element of lasting influence. Our AI evaluates:</p>

                <div className="space-y-4">
                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Expertise</h3>
                    <p className="text-sm text-muted-foreground">
                      Demonstrated knowledge, skills, and qualifications in their field. Includes formal credentials,
                      practical experience, and peer recognition.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Consistency</h3>
                    <p className="text-sm text-muted-foreground">
                      Alignment between statements and actions over time. Measures how reliably the figure delivers on
                      promises and maintains positions.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Transparency</h3>
                    <p className="text-sm text-muted-foreground">
                      Openness about methods, motivations, and mistakes. Evaluates disclosure practices and willingness
                      to share information.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Accuracy</h3>
                    <p className="text-sm text-muted-foreground">
                      Factual correctness of public statements and claims. Analyzes fact-checking results and correction
                      patterns.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Accountability</h3>
                    <p className="text-sm text-muted-foreground">
                      Taking responsibility for outcomes and mistakes. Measures how the figure responds to failures and
                      criticism.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Third-party Validation</h3>
                    <p className="text-sm text-muted-foreground">
                      Recognition from respected authorities and institutions. Includes awards, endorsements, and expert
                      citations.
                    </p>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg mt-6">
                  <h3 className="font-medium mb-2">Credibility Calculation</h3>
                  <p className="text-sm">
                    Each credibility factor is weighted according to relevance in the figure's field. For example,
                    accuracy is weighted more heavily for journalists, while expertise might be weighted more for
                    scientists. Our AI continuously refines these weights based on evolving standards in each industry.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relevance" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Relevance Methodology</CardTitle>
                <CardDescription>How we measure sustained significance over time</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>Relevance distinguishes lasting influence from fleeting fame. Our system evaluates:</p>

                <div className="space-y-4">
                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Sustained Attention</h3>
                    <p className="text-sm text-muted-foreground">
                      Consistent public interest over extended periods rather than short spikes. Measures long-term
                      engagement patterns across platforms.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Cultural Significance</h3>
                    <p className="text-sm text-muted-foreground">
                      Integration into broader cultural conversations and references. Analyzes mentions in diverse
                      contexts beyond primary field.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Adaptability</h3>
                    <p className="text-sm text-muted-foreground">
                      Ability to remain relevant through changing trends and circumstances. Evaluates evolution of
                      messaging and positioning over time.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Audience Retention</h3>
                    <p className="text-sm text-muted-foreground">
                      Maintaining and growing engaged followers over time. Measures not just quantity but quality of
                      audience interaction.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Cross-platform Presence</h3>
                    <p className="text-sm text-muted-foreground">
                      Relevance across multiple channels and mediums. Analyzes effectiveness across different platforms
                      and formats.
                    </p>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg mt-6">
                  <h3 className="font-medium mb-2">Relevance Calculation</h3>
                  <p className="text-sm">
                    Our AI analyzes temporal patterns in attention and engagement, prioritizing consistent relevance
                    over viral spikes. The system compares current relevance to historical baselines, rewarding figures
                    who maintain or grow their significance over time rather than experiencing rapid rises and falls.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="impact" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Impact Methodology</CardTitle>
                <CardDescription>How we measure tangible influence and lasting change</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  Impact measures the actual effect a public figure has on their field, industry, or society. Our system
                  evaluates:
                </p>

                <div className="space-y-4">
                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Direct Outcomes</h3>
                    <p className="text-sm text-muted-foreground">
                      Tangible results directly attributable to the figure's actions. Includes business metrics, policy
                      changes, or measurable achievements.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Industry Influence</h3>
                    <p className="text-sm text-muted-foreground">
                      Effect on practices, standards, or direction within their field. Measures how competitors and
                      colleagues respond to their actions.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Behavioral Change</h3>
                    <p className="text-sm text-muted-foreground">
                      Ability to influence actions and decisions of others. Analyzes changes in audience behavior
                      following their guidance.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Innovation Catalyst</h3>
                    <p className="text-sm text-muted-foreground">
                      Sparking new ideas, approaches, or movements. Measures derivative works, citations, or inspired
                      initiatives.
                    </p>
                  </div>

                  <div className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium">Legacy Potential</h3>
                    <p className="text-sm text-muted-foreground">
                      Likelihood of lasting influence beyond active career. Evaluates creation of enduring institutions,
                      ideas, or works.
                    </p>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg mt-6">
                  <h3 className="font-medium mb-2">Impact Calculation</h3>
                  <p className="text-sm">
                    Impact is measured through a combination of quantitative metrics (market movements, citation counts,
                    adoption rates) and qualitative analysis (expert assessments, case studies, historical comparisons).
                    Our AI contextualizes impact relative to the figure's resources and position, recognizing that
                    meaningful impact can occur at different scales.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

